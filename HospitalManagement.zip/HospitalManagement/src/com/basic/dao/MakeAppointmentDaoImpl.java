package com.basic.dao;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.basic.model.Appointment;
import com.basic.model.Doctorschedule;

@Repository("makeAppointmentDao")
public class MakeAppointmentDaoImpl implements MakeAppointmentDao {
	private static final Logger logger = Logger.getLogger(MakeAppointmentDaoImpl.class.getName());
    @Autowired
    private SessionFactory sessionFactory;
    private Session session;
	@Override
	public List<Doctorschedule> getDoctorId(String todayDate) {
		List<Doctorschedule> getAllDoctorId=null;
	try {
		session = sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Doctorschedule
				.class);
		criteria.add(Restrictions.ilike("dayOfWeek",
				todayDate+"%"));
		getAllDoctorId=(List<Doctorschedule>)criteria.list();
	} catch (Exception e) {
		logger.error("Exception in MakeAppointmentDaoImpl getDoctorId() method :"
				+e.getMessage(),e);
	}
		return getAllDoctorId;
	}
	@Override
	public Appointment isExists(BigInteger doctorId, Date appointmentTime) {
		// TODO Auto-generated method stub
		Appointment  appointment= null;
		try{
			logger.info("Inside the isExists() in   MakeAppointmentDaoImpl();");
		boolean blstatus=false;
		session = sessionFactory.getCurrentSession();
	    Criteria criteria = session.createCriteria(Appointment.class);
	    criteria.add(Restrictions.eq("doctorId",doctorId));
	    criteria.add(Restrictions.eq("appTime",appointmentTime));
	    Criterion rest1= Restrictions.eq("status","Scheduled"); 
        Criterion rest2= Restrictions.eq("status","Arrived"); 
	    Criterion or1=Restrictions.or(rest1, rest2);
	    criteria.add(or1);
	    appointment=(Appointment)criteria.uniqueResult(); 
	    return appointment;
	    
		}catch(Exception e){
			e.printStackTrace();
			logger.error("Exception isExists() in MakeAppointmentDaoImpl "+e.getMessage(),e);
		}
	      return appointment;}
	@Override
	public boolean saveServiceAppointment(Appointment appointment) {

		boolean blStatus = false;
		try {
			logger.info("Inside the saveServiceAppointment()method in MakeAppointmentDaoImpl");
			session = sessionFactory.getCurrentSession();
			session.save(appointment);
			blStatus = true;
		} catch (Exception e) {
			logger.error("Exception saveServiceAppointment() method in MakeAppointmentDaoImpl "+e.getMessage(),e);
		}
		logger.info("returns from saveServiceAppointment() in method MakeAppointmentDaoImpl "+blStatus);
		return blStatus;
	}
	@Override
	public List<Doctorschedule> getAllDoctorScheduleTime(String doctorId, String dayOfWeek) {
		List<Doctorschedule> getAllDoctorScheduleTime=null;
		try {
			session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(Doctorschedule
					.class);
			
			criteria.add(Restrictions.eq("doctorId",
					(doctorId)));
			criteria.add(Restrictions.eq("dayOfWeek",dayOfWeek));
			getAllDoctorScheduleTime=(List<Doctorschedule>)criteria.list();
			System.out.println(getAllDoctorScheduleTime.size());
		} catch (Exception e) {
			logger.info("Exception in MakeAppointmentDaoImpl getAllDoctorScheduleTime() method :"
					+ e);
		}
		System.out.println(getAllDoctorScheduleTime.size()+":::::::::::::::::::::::::::");
			return getAllDoctorScheduleTime;}
	@Override
	public List<Appointment> getIsTimeTakenBySomeOneElse(String doctorId, Date sheduleDate) {
		List <Appointment> isTimeTakenBySomeOneElse=null;
		try{
			logger.info("Inside the getVitalSignNumber() in   MakeAppointmentDaoImpl();");
			session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(Appointment.class);
		    criteria.add(Restrictions.eq("doctorId",new BigInteger(doctorId)));
		    criteria.add(Restrictions.eq("appTime",sheduleDate)); 		    
		    isTimeTakenBySomeOneElse=(List <Appointment>)criteria.list();
		    
		}catch(Exception e){
			logger.info("Exception in Make appointment getVitalSignNumber() method :"+ e);
		}
		return isTimeTakenBySomeOneElse;
	}
}
