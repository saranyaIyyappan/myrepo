package com.basic.dao;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import com.basic.model.Appointment;
import com.basic.model.Doctorschedule;

public interface MakeAppointmentDao {

	public List<Doctorschedule> getDoctorId(String todayDate) ;

	public Appointment isExists(BigInteger doctorId, Date appointmentTime);

	public boolean saveServiceAppointment(Appointment appointment);

	public List<Doctorschedule> getAllDoctorScheduleTime(String doctorId, String dayOfWeek);

	public List<Appointment> getIsTimeTakenBySomeOneElse(String doctorId, Date sheduleDate);

}
