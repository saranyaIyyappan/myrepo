package com.basic.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.basic.dao.DocterScheduleDao;
import com.basic.model.Doctorschedule;
import com.basic.model.Employees;
@Repository("DocterScheduleDao")
public class DocterScheduleDaoImpl implements DocterScheduleDao {
	@Autowired
    private SessionFactory sessionFactory;
	 private Session session;
	@Override
	public boolean saveDoctorScheduleDetails(Doctorschedule doctorschedule) {
		boolean blStatus=false;
		try {
System.out.println("Inside saveGroupDetails() in DocterScheduleDaoImpl");
			session.clear();
			session = sessionFactory.getCurrentSession();
			session.save(doctorschedule);;
			blStatus=true;
		} catch (Exception e) {
			System.out.println("Exception saveDoctorScheduleDetails() in DocterScheduleDaoImpl "+e.getMessage());
		}
		System.out.println("Return from saveDoctorScheduleDetails() in DocterScheduleDaoImpl and the returned value is "+blStatus);
		return blStatus;
	}

	@Override
	public List<Doctorschedule> getDoctorScheduleByIDTest(String DoctorId,
			String dayOfWeek) {
		List<Doctorschedule> doctorschedule = null;
		try {
			System.out.println("Inside the getGroupByID() in DocterScheduleDaoImpl");
			session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(Doctorschedule.class);
			criteria.add(Restrictions.eq("doctorId",DoctorId));
			criteria.add(Restrictions.eq("dayOfWeek",dayOfWeek));
			
			doctorschedule = (List<Doctorschedule> ) criteria.list();
		} catch (Exception e) {
		System.out.println("Exception getDoctorScheduleByIDTest() in DocterScheduleDaoImpl "+e.getMessage());
		}
	   return doctorschedule;
	}

	@Override
	public List<Doctorschedule> getAllDoctorScheduleTime(String clinicId, Date date, String day) {
		// TODO Auto-generated method stub
		List<Doctorschedule> doctorSheduleList=null;
		try {
			session = sessionFactory.getCurrentSession();  
			Criteria criteria = session.createCriteria(Doctorschedule.class); 
			criteria.add(Restrictions.eq("doctorId",clinicId));
			//criteria.add(Restrictions.eq("dateCre",date));
			criteria.addOrder(Order.desc("dateCre"));
			criteria.add(Restrictions.eq("dayOfWeek",day));
			//criteria.add(Restrictions.eq("doctorId",Long.parseLong(doctorId)));
			doctorSheduleList=(List<Doctorschedule>)criteria.list();
		} catch (Exception e) {
			System.out.println("Exception in GroupDaoImpl getDoctorSheduleListSize() method :"+ e); 
		}
		return doctorSheduleList;
	}

	@Override
	public List<Doctorschedule> getAllDoctorScheduleTime(String clinicId, Date date) {
		List <Doctorschedule>getAllCodeIdFromClinicMaster=null;  
	try { 
		System.out.println("HELLOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO");
		session = sessionFactory.getCurrentSession();  
		Criteria criteria = session.createCriteria(Doctorschedule.class); 
		criteria.add(Restrictions.eq("doctorId",clinicId));
		criteria.add(Restrictions.ilike("designation","doctor"));
		criteria.add(Restrictions.eq("empStatus","1"));
		//criteria.setProjection(Projections.distinct(Projections.property("clinicId")));
		getAllCodeIdFromClinicMaster=(List<Doctorschedule>)criteria.list(); 
		} catch (Exception e) {  
			System.out.println("Exception in DoctorScheduleDaoImpl getAllDoctorIdFromDoctorSchedule() method :"+ e); 
			} 
	return getAllCodeIdFromClinicMaster;
}

	@Override
	public Employees getAllDoctorName(String doctorId) {
		// TODO Auto-generated method stub
		Employees  employee=null;
		try { 
			session = sessionFactory.getCurrentSession();  
			Criteria criteria = session.createCriteria(Employees.class);
			criteria.add(Restrictions.eq("employeeName",doctorId));		
			employee=(Employees)criteria.uniqueResult(); 
			} catch (Exception e) {  
				employee=null;
				System.out.println("Exception in DocterScheduleDaoImpl getAllDoctorName() method :"+e.getMessage()); 
				} 
		return employee;
	}

}
