package com.basic.dto;

import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

public class AppointmentDto {
    private String doctorId;
    private String appTime;
    private String arrTime;
    private String outTime;
    private String triage;
    private String purpose;
    private String appoinmentType;
    private String remarks;
    private String status;
    private String enterdby;
    private String dateCre;
    private String updatedby;
    private String dateUpd;
    private String mrNo;
    private String dayOfWeek;
	public String getDayOfWeek() {
		return dayOfWeek;
	}
	public void setDayOfWeek(String dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}
	public String getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}
	public String getAppTime() {
		return appTime;
	}
	public void setAppTime(String appTime) {
		this.appTime = appTime;
	}
	public String getArrTime() {
		return arrTime;
	}
	public void setArrTime(String arrTime) {
		this.arrTime = arrTime;
	}
	public String getOutTime() {
		return outTime;
	}
	public void setOutTime(String outTime) {
		this.outTime = outTime;
	}
	public String getTriage() {
		return triage;
	}
	public void setTriage(String triage) {
		this.triage = triage;
	}
	public String getPurpose() {
		return purpose;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	public String getAppoinmentType() {
		return appoinmentType;
	}
	public void setAppoinmentType(String appoinmentType) {
		this.appoinmentType = appoinmentType;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getEnterdby() {
		return enterdby;
	}
	public void setEnterdby(String enterdby) {
		this.enterdby = enterdby;
	}
	public String getDateCre() {
		return dateCre;
	}
	public void setDateCre(String dateCre) {
		this.dateCre = dateCre;
	}
	public String getUpdatedby() {
		return updatedby;
	}
	public void setUpdatedby(String updatedby) {
		this.updatedby = updatedby;
	}
	public String getDateUpd() {
		return dateUpd;
	}
	public void setDateUpd(String dateUpd) {
		this.dateUpd = dateUpd;
	}
	public String getMrNo() {
		return mrNo;
	}
	public void setMrNo(String mrNo) {
		this.mrNo = mrNo;
	}
	
	
    

}
