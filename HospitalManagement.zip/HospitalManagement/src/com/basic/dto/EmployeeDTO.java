package com.basic.dto;

import java.util.Date;

public class EmployeeDTO {
    private Integer employeeCode;
    private String designation;
    private String addressPresent;
    private String addressPermenant;
    private String mobile;
    private String email;
    private String insNo;
    private String empStatus;
    private String remarks;
    private String enterdby;
    private Date dateCre;
    private String updatedby;
    private Date dateUpd;
    private String firstName;
    public Integer getEmployeeCode() {
		return employeeCode;
	}
	public void setEmployeeCode(Integer employeeCode) {
		this.employeeCode = employeeCode;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getAddressPresent() {
		return addressPresent;
	}
	public void setAddressPresent(String addressPresent) {
		this.addressPresent = addressPresent;
	}
	public String getAddressPermenant() {
		return addressPermenant;
	}
	public void setAddressPermenant(String addressPermenant) {
		this.addressPermenant = addressPermenant;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getInsNo() {
		return insNo;
	}
	public void setInsNo(String insNo) {
		this.insNo = insNo;
	}
	public String getEmpStatus() {
		return empStatus;
	}
	public void setEmpStatus(String empStatus) {
		this.empStatus = empStatus;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getEnterdby() {
		return enterdby;
	}
	public void setEnterdby(String enterdby) {
		this.enterdby = enterdby;
	}
	public Date getDateCre() {
		return dateCre;
	}
	public void setDateCre(Date dateCre) {
		this.dateCre = dateCre;
	}
	public String getUpdatedby() {
		return updatedby;
	}
	public void setUpdatedby(String updatedby) {
		this.updatedby = updatedby;
	}
	public Date getDateUpd() {
		return dateUpd;
	}
	public void setDateUpd(Date dateUpd) {
		this.dateUpd = dateUpd;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	private String middleName;
    private String lastName;
    
}
