package com.basic.service;

import org.json.simple.JSONObject;

import com.basic.dto.AppointmentDto;

public interface MakeAppointmentService {

	public String getDoctorSchedule(String todayDate) ;

	public JSONObject saveMakeAppointment(AppointmentDto appointmentDto);

	public String getAllDoctorScheduleTime(String doctorId, String dayOfWeek, String appointmentDate, String time);

}
