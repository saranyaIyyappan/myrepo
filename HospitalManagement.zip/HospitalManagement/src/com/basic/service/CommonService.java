package com.basic.service;

import com.basic.dto.EmployeeDTO;
import com.basic.dto.UserDto;
import com.basic.model.User;


public interface CommonService {
    User login(UserDto userDTO);

	String getAllDetails(String userName,String status);

	String saveEmployee(EmployeeDTO employeeDTO);

	

}
