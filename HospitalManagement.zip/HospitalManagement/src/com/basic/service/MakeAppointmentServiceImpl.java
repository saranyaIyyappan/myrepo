package com.basic.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.basic.model.Doctorschedule;
import com.basic.model.Employees;
import com.basic.dao.DocterScheduleDao;
import com.basic.dao.MakeAppointmentDao;
import com.basic.dto.AppointmentDto;
import com.basic.model.Appointment;

@Service("makeAppointmentService")
@Transactional
public class MakeAppointmentServiceImpl implements MakeAppointmentService{
	private static final Logger logger = Logger
			.getLogger(MakeAppointmentServiceImpl.class.getName());
	@Autowired
	MakeAppointmentDao makeAppointmentDao;
	@Autowired
	DocterScheduleDao doctorscheduleDao;

	@Override
	public String getDoctorSchedule(String todayDate) {
		
		JSONArray arrDoctorSchedule=new JSONArray();
		try {  
			List<Doctorschedule> getDoctorSchedule=makeAppointmentDao.getDoctorId(todayDate);
			String[] myArray = new String [getDoctorSchedule.size()] ;
			for (int x=0; x<getDoctorSchedule.size();x++) {
				myArray[x]=String.valueOf(getDoctorSchedule.get(x).getDoctorId());
			}
			Set<String> set = new HashSet<String>(Arrays.asList(myArray));
			String[] empArray = set.toArray(new String[set.size()]);
			for (int i = 0; i < empArray.length; i++) {
				Employees doctor=doctorscheduleDao.getAllDoctorName((empArray[i]));	
				  JSONObject jsonObjAllCodes = new JSONObject();	
					jsonObjAllCodes.put("doctorId", empArray[i]);
					
					arrDoctorSchedule.add(jsonObjAllCodes);
			}
					
			}
		catch (Exception e) {  
			logger.info("Exception in MakeAppointmentServiceImpl getDoctorSchedule() method :" +e.getMessage(),e); 
			}
		
		return arrDoctorSchedule.toString(); 

	}

	@Override
	public JSONObject saveMakeAppointment(AppointmentDto appointmentDto) {
		
		JSONObject res = new JSONObject();
		try {
			SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); ;
		BigInteger doctorId=new BigInteger(appointmentDto.getDoctorId());
		Date appointmentTime=dateFormatter.parse(appointmentDto.getAppTime());
			Appointment appointmentList= makeAppointmentDao.isExists(doctorId,appointmentTime);
			if (StringUtils.isEmpty(appointmentList)) {
			Appointment appointment=new Appointment();
			
			appointment.setPurpose(appointmentDto.getPurpose());
			appointment.setDoctorId(appointmentDto.getDoctorId());
			appointment.setStatus("Scheduled");
				
			appointment.setAppTime(dateFormatter.parse(appointmentDto.getAppTime()));
			
			appointment.setDayOfWeek(appointmentDto.getDayOfWeek());
			
		    
			appointment.setDateCre(new Date());
			
			boolean blsaveStatus = makeAppointmentDao.saveServiceAppointment(appointment);
			if(blsaveStatus){
				res.put("status","Success");
				res.put("message","Appointment Saved Successfully");
			}else{
				res.put("status","Failed");
				res.put("message","Failed to book Appointment ");
			}
			}
			else{
				res.put("status","Failed");
				res.put("message","Appointment already booked.Please select different time ");
			}
			}
			
		catch (Exception e) {
			logger.error("Exception in MakeAppointmentServiceImpl saveMakeAppointment() method :"     +e.getMessage(),e); 

		}
		return res;
	}

	@SuppressWarnings("deprecation")
	@Override
	public String getAllDoctorScheduleTime(String doctorId, String dayOfWeek, String appointmentDate, String time) {
		JSONArray arrDoctorScheduleTime=new JSONArray();
		try {

		List<BigDecimal>myList=new ArrayList<BigDecimal>();

		List<Doctorschedule>doctorScheduleTime=makeAppointmentDao.getAllDoctorScheduleTime(doctorId,dayOfWeek);
		for (Doctorschedule Doctorschedule: doctorScheduleTime) {
			
			java.util.Date fromDate = new java.util.Date();      
			java.util.Date toDate = new java.util.Date(); 
			
			System.out.println(fromDate);
			 String fromDateFromDB=Doctorschedule.getTimeFrom();
			 String dataFrom[]=fromDateFromDB.split(":");			 
			 fromDate.setHours(Integer.parseInt(dataFrom[0]));      
			 fromDate.setMinutes(Integer.parseInt(dataFrom[1]));   
			 
			 String toDateFromDB=Doctorschedule.getTimeTo();
			 String dataTo[]=toDateFromDB.split(":");			 
			 toDate.setHours(Integer.parseInt(dataTo[0]));      
			 toDate.setMinutes(Integer.parseInt(dataTo[1]));
			 
			 java.text.SimpleDateFormat dateFormatter = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			 String fromTime = dateFormatter.format(fromDate);  
			 String toTime = dateFormatter.format(toDate); 
			 
			 java.util.Date from = dateFormatter.parse(fromTime);      
			 java.util.Date to = dateFormatter.parse(toTime);      
			 
			 long difference = to.getTime()-from.getTime() ; 
			
			 
			 double slotes=TimeUnit.MILLISECONDS.toMinutes(difference)/15; 
			 int time1 =Integer.parseInt(dataFrom[1]);        
			 int hr=Integer.parseInt(dataFrom[0]);  
			
			 String dVal="";
			  for(int x=0;x<slotes;x++){   
				  		if(x==0){
				  		dVal=hr+":"+time1;
				  		}else  if(time1>=45){					 
						 hr=hr+1;
						 time1=15-(60-time1);
					  }else{
					     time1=time1+15;
					  }
				  			if(time1<=9){
				  			dVal=hr+":0"+time1;
				  		}else{
				  	  dVal=hr+":"+time1;
				  		}
				  	  System.out.println(">>>>>>>>>>>>>>>>>>>>>"+dVal+">>>>>>>>>>>");
				  	  dVal=dVal.replaceAll(":", ".");
					  myList.add(new BigDecimal(dVal));
				
			}			

			
		}
		
		SimpleDateFormat dateF = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		//
		Collections.sort(myList);
		
		JSONObject jsonObjScheduledTime = new JSONObject();
		for (int xx=0;xx<myList.size();xx++) {
			jsonObjScheduledTime=new JSONObject();
			String time1=(myList.get(xx).toString()).replace(".", ":");
			Date sheduleDate= dateF.parse(appointmentDate+" "+time1+":00");
			  //call a function to check this time is taken by some one else
			 List <Appointment> isTimeTakenBySomeOneElse=makeAppointmentDao.getIsTimeTakenBySomeOneElse(doctorId,sheduleDate);
			 if(isTimeTakenBySomeOneElse.size()>0){
				 jsonObjScheduledTime.put("statusColor","green");
			 }
			
			 
			 jsonObjScheduledTime.put("scheduledTime",time1);
			 arrDoctorScheduleTime.add(jsonObjScheduledTime);
		}
		
		//
			
		}
		catch (Exception e) {  
			logger.info("Exception in MakeAppointmentServiceImpl getAllDoctorScheduleTime() method :"     + e); 
			}
		return arrDoctorScheduleTime.toString(); 
	}
}
