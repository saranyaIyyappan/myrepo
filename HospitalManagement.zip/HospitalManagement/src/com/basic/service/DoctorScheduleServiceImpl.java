package com.basic.service;

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.basic.dto.ScheduleDto;
import com.basic.dao.DocterScheduleDao;
import com.basic.model.Doctorschedule;

@Service("DoctorScheduleService")
@Transactional
public class DoctorScheduleServiceImpl implements DoctorScheduleService{
	@Autowired
    DocterScheduleDao docterScheduleDao;
	@Override
	public String saveDocterScheduleTest(ScheduleDto docterScheduledto) {
		JSONParser parser = new JSONParser();
		JSONObject stringReturnStatus = new JSONObject();
		String status=null;
		if((docterScheduledto.getDayofWeak()).equals("everyday")){
			for(int i=1;i<=7;i++){
				if(i==1){
					docterScheduledto.setDayofWeak("Sunday");
					stringReturnStatus=saveDocterScheduleTestDummy(docterScheduledto);
					String string =(String) (stringReturnStatus.get("message"));
					String string2="This schedule already exists";
					//stringReturnStatus.put("message","Scheduled on sunday already exist");
					if((string.equals(string2)))
					{
						stringReturnStatus.put("status","");
						stringReturnStatus.put("message","Schedule on sunday already exist");
						return stringReturnStatus.toString();
					}
				}else if(i==2){
					docterScheduledto.setDayofWeak("Monday");
					stringReturnStatus=saveDocterScheduleTestDummy(docterScheduledto);
					if(("This schedule already exists").equals((String) stringReturnStatus.get("message")))
					{
						stringReturnStatus.put("status","");
						stringReturnStatus.put("message","Schedule monday already exist");
						return stringReturnStatus.toString();
					}
				}else if(i==3){
					docterScheduledto.setDayofWeak("Tuesday");
					stringReturnStatus=saveDocterScheduleTestDummy(docterScheduledto);
					if(("This schedule already exists").equals((String) stringReturnStatus.get("message")))
					{
						stringReturnStatus.put("status","");
						stringReturnStatus.put("message","Schedule on tuesday already exist");
						return stringReturnStatus.toString();
					}
					
				}else if(i==4){
					docterScheduledto.setDayofWeak("Wednesday");
					stringReturnStatus=saveDocterScheduleTestDummy(docterScheduledto);
					if(("This schedule already exists").equals((String) stringReturnStatus.get("message")))
					{
						stringReturnStatus.put("status","");
						stringReturnStatus.put("message","Schedule on wednesday already exist");
						return stringReturnStatus.toString();
					}
					
				}else if(i==5){
					docterScheduledto.setDayofWeak("Thursday");
					stringReturnStatus=saveDocterScheduleTestDummy(docterScheduledto);
					if(("This schedule already exists").equals((String) stringReturnStatus.get("message")))
					{
						stringReturnStatus.put("status","");
						stringReturnStatus.put("message","Schedule on thursday already exist");
						return stringReturnStatus.toString();
					}
					
				}else if(i==6){
					docterScheduledto.setDayofWeak("Friday");
					stringReturnStatus=saveDocterScheduleTestDummy(docterScheduledto);
					if(("This schedule already exists").equals((String) stringReturnStatus.get("message")))
					{
						stringReturnStatus.put("status","");
						stringReturnStatus.put("message","Schedule on friday already exist");
						return stringReturnStatus.toString();
					}
					
				}else if(i==7){
					docterScheduledto.setDayofWeak("Saturday");
					stringReturnStatus=saveDocterScheduleTestDummy(docterScheduledto);
					if(("This schedule already exists" ).equals((String) stringReturnStatus.get("message")))
					{
						stringReturnStatus.put("status","");
						stringReturnStatus.put("message","Schedule on saturday already exist");
						return stringReturnStatus.toString();
					}
					
					
				}
			}
		}else{
			stringReturnStatus=saveDocterScheduleTestDummy(docterScheduledto);
			return stringReturnStatus.toString();
		}
		return stringReturnStatus.toString();
}
	private JSONObject saveDocterScheduleTestDummy(ScheduleDto docterScheduledto) {
		
		Date date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		JSONObject stringReturnStatus = new JSONObject();
		List<Doctorschedule> doctorscheduleList =null;
		Doctorschedule doctorscheduleNew=null; 
		int scedulednumber=1;
        int flagsucsess=0;
        int flagfail=0;
		try {
			System.out.println("Inside saveDocterScheduleTestDummy() in DoctorServiceImpl with   Id:"+ docterScheduledto.getDoctorId()+docterScheduledto.getDayofWeak());
			doctorscheduleList= docterScheduleDao.getDoctorScheduleByIDTest(docterScheduledto.getDoctorId(),docterScheduledto.getDayofWeak());
			
			
			if((doctorscheduleList!=null)&&(doctorscheduleList.size()>0)){
				for (Doctorschedule doctorscheduleItrator : doctorscheduleList) {
					String fromDB[]=(doctorscheduleItrator.getTimeFrom()).split(":");					
					String fromDTO[]=(docterScheduledto.getTimeFrom()).split(":");
					
					String toDB[]=(doctorscheduleItrator.getTimeTo()).split(":");					
					String toDTO[]=(docterScheduledto.getTimeTo()).split(":");
					
					/*float fromHourDB=Float.parseFloat(fromDB[0]);
					float fromHourDTO=Float.parseFloat(fromDTO[0]);
					float fromMinuteDB=Float.parseFloat(fromDB[1]);
					float fromMinuteDTO=Float.parseFloat(fromDTO[1]);
					
					float toHourDB=Float.parseFloat(toDB[0]);
					float toHourDTO=Float.parseFloat(toDTO[0]);
					float toMinuteDB=Float.parseFloat(toDB[1]);
					float toMinuteDTO=Float.parseFloat(toDTO[1]);*/
					
				
				}
				
				if(flagfail==1){
					System.out.println("Doctor Already Exists with given Userid "+docterScheduledto.getDoctorId());
					stringReturnStatus.put("status", "Fail");
					stringReturnStatus.put("message", "This schedule already exists");
					return stringReturnStatus;
				}
				else
				{	doctorscheduleNew=new Doctorschedule();
					scedulednumber=flagsucsess+1;
					doctorscheduleNew.setScheduledNumber(scedulednumber);
					doctorscheduleNew.setTimeFrom(docterScheduledto.getTimeFrom());
					doctorscheduleNew.setTimeTo(docterScheduledto.getTimeTo());
					doctorscheduleNew.setDoctorId(docterScheduledto.getDoctorId());
					doctorscheduleNew.setDayOfWeek( docterScheduledto.getDayofWeak());
					doctorscheduleNew.setEnterdby(docterScheduledto.getEnteredBy());
					doctorscheduleNew.setUpdatedby(docterScheduledto.getUpdatedby());
					
					doctorscheduleNew.setDateCre(date);
					doctorscheduleNew.setDateUpd(date);
					boolean status = docterScheduleDao.saveDoctorScheduleDetails(doctorscheduleNew);
					if (status) {
						stringReturnStatus.put("status", "Success");
						stringReturnStatus.put("message","Doctor schedule created Successfully");
						
					} else {
						stringReturnStatus.put("status", "Fail");
						stringReturnStatus.put("message", "Doctor schedule not saved please try after some time");
						return stringReturnStatus;
					}
					
				}
			}else{
				Doctorschedule doctorschedule = new Doctorschedule();
				doctorschedule.setScheduledNumber(scedulednumber);
				doctorschedule.setTimeFrom(docterScheduledto.getTimeFrom());
				doctorschedule.setTimeTo(docterScheduledto.getTimeTo());
				doctorschedule.setDoctorId(docterScheduledto.getDoctorId());
				doctorschedule.setDayOfWeek( docterScheduledto.getDayofWeak());
				doctorschedule.setEnterdby(docterScheduledto.getEnteredBy());
				doctorschedule.setUpdatedby(docterScheduledto.getUpdatedby());
				
				doctorschedule.setDateCre(date);
				doctorschedule.setDateUpd(date);
				boolean status = docterScheduleDao.saveDoctorScheduleDetails(doctorschedule);
				if (status) {
					stringReturnStatus.put("status", "Success");
					stringReturnStatus.put("message","Doctor schedule created successfully");
					
				} else {
					stringReturnStatus.put("status", "Fail");
					stringReturnStatus.put("message", "Doctor schedule saved please try after some time");
					return stringReturnStatus;
				}
			}
			
		
		
			
			} catch (Exception e) {
				System.out.println("Exception in method saveDocterScheduleTestDummy() in  DoctorServiceImpl"+ e.getMessage());
		}
		System.out.println("Status from save Doctor Details from saveDocterScheduleTestDummy() in DoctorServiceImpl"+ stringReturnStatus.toString());
		return stringReturnStatus;
	
				
		}
	@Override
	public String cretedTimeSchedule(String clinicId, String selectedDay) {
		JSONArray arrDoctorScheduleTime=new JSONArray();
		JSONArray resultArray=new JSONArray();
		List<Doctorschedule>doctorScheduleTime=null;
		try {
			Date date=new Date();
			
		List <Double> myList=new ArrayList<>();	
		if(selectedDay.equals("everyday")){
			String day="Monday";
			doctorScheduleTime=docterScheduleDao.getAllDoctorScheduleTime(clinicId,date,day);
		}else{
		    doctorScheduleTime=docterScheduleDao.getAllDoctorScheduleTime(clinicId,date);
		}
		double additional=0;
		//for (Doctorschedule Doctorschedule: doctorScheduleTime) {
			//JSONObject jsonObjScheduledTime = new JSONObject();
			java.util.Date fromDate = new java.util.Date();      
			java.util.Date toDate = new java.util.Date(); 
			
			 String fromDateFromDB=doctorScheduleTime.get(0).getTimeFrom();
			 String dataFrom[]=fromDateFromDB.split(":");			 
			 fromDate.setHours(Integer.parseInt(dataFrom[0]));      
			 fromDate.setMinutes(Integer.parseInt(dataFrom[1]));   
			 
			 String toDateFromDB=doctorScheduleTime.get(0).getTimeTo();
			 String dataTo[]=toDateFromDB.split(":");			 
			 toDate.setHours(Integer.parseInt(dataTo[0]));      
			 toDate.setMinutes(Integer.parseInt(dataTo[1]));
			 
			 java.text.SimpleDateFormat dateFormatter = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			 String fromTime = dateFormatter.format(fromDate);  
			 String toTime = dateFormatter.format(toDate); 
			 
			 java.util.Date from = dateFormatter.parse(fromTime);      
			 java.util.Date to = dateFormatter.parse(toTime);      
			 
			 long difference = to.getTime()-from.getTime() ;      
			 long Minutes = difference / (60 * 1000);     
			 long diffMinutes = difference / (60 * 1000) % 60;       
			 long diffHours = difference / (60 * 60*  1000) % 24; 		 
			 double slotes=TimeUnit.MILLISECONDS.toMinutes(difference)/15;  
			 int slo=(int)slotes;
			 double additionalMinutes=TimeUnit.MILLISECONDS.toMinutes(difference)%15;    
			 additional=additionalMinutes;
			 SimpleDateFormat dateF = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
			 int time=Integer.parseInt(dataFrom[1]);   
			 int hr=Integer.parseInt(dataFrom[0]);  
			 String dVal="";
			  for(int x=0;x<=slotes;x++){   
				  		if(x==0){
				  		dVal=hr+":"+time;
				  		}else  if(time>=45){					 
						 hr=hr+1;
						 time=15-(60-time);
					  }else{
					     time=time+15;
					  }
				  			if(time<=9){
				  			dVal=hr+":0"+time;
				  		}else{
				  	  dVal=hr+":"+time;
				  		}
				  	  System.out.println(">>>>>>>>>>>>>>>>>>>>>"+dVal+">>>>>>>>>>>");
				  	  dVal=dVal.replaceAll(":", ".");
					  myList.add(Double.parseDouble(dVal));
				
			}
			  System.out.println(additionalMinutes+">>>>>>>>>>>>additional minutes");
			
		//}
		//Collections.sort(myList);
		if(additional>0){
			System.out.println(":::::::::::::::::::DONT REMOVE "+additional);
		}else{
			System.out.println(":::::::::::::::::::REMOVE "+additional);
			myList.remove(myList.size()-1);
			System.out.println("MMMMMMMMMMMMMMMMMMM"+myList.get(myList.size()-1));
		}
		JSONObject jsonObjScheduledTime = new JSONObject();
		for (int xx=0;xx<=myList.size();xx++) {
			jsonObjScheduledTime=new JSONObject();
			System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>"+myList.get(xx).toString()+">>>>>>>>>>>>>>>>FINAL");
			 jsonObjScheduledTime.put("scheduledTime",myList.get(xx).toString());
			 resultArray.add(jsonObjScheduledTime);
		}
		
		}catch(Exception e){
			System.out.println("Exception in finding available time of doctor");
		}
	System.out.println(resultArray.toString());
		return resultArray.toString();
	}

}
