package com.basic.controller;

import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.basic.service.MakeAppointmentService;
import com.basic.dto.AppointmentDto;

@Controller
@RequestMapping("/makeAppointment")
public class MakeAppointmentController {private static final Logger logger = Logger
.getLogger(MakeAppointmentController.class.getName());
@Autowired
MakeAppointmentService makeAppointmentService;
	@RequestMapping(value = "/getDoctorSchedule" , method ={RequestMethod.GET,RequestMethod.POST})  
	public @ResponseBody String getDoctorSchedule(Model model, HttpServletRequest request){ 
		
		   String returnStatus="";  
		   try {
			   HttpSession session = request.getSession();
			   String todayDate=request.getParameter("todayDate");
			   returnStatus=makeAppointmentService.getDoctorSchedule(todayDate);
			   } catch (Exception e) {
				   System.out.println("Exception in MakeAppointmentController getDoctorSchedule() method :"     +e.getMessage()); 
				   }     
		   return returnStatus; 
		   }

	@RequestMapping(value = "/saveMakeAppointment", method = {RequestMethod.POST,RequestMethod.GET})
	public @ResponseBody String saveMakeAppointment(HttpServletRequest request) {

	JSONObject objStatus=new JSONObject();

		try{
			HttpSession session = request.getSession();
			
			String clinicId = (String) session.getAttribute("clinicId");
			String appointmentTime=request.getParameter("appointmentTime");
			String appointmentDate=request.getParameter("appointmentDate");
			String doctor=request.getParameter("doctorId");
			String purpose=request.getParameter("purpose");
			String appointmentDay=request.getParameter("appointmentDay");
			logger.info(appointmentDay+"<<<<<<<<<<<<<<<<<<<<<<<<<<<<<asd>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
			String mrNo=(String) session.getAttribute("userId");
			String data[]=appointmentTime.split(":");
			String date[]=appointmentDate.split("-");
			
			 Calendar cal = Calendar.getInstance();
			 cal.set(Integer.parseInt(date[0]), Integer.parseInt(date[1])-1, Integer.parseInt(date[2]));
			 java.util.Date appointmentDateTime =cal.getTime();
			 appointmentDateTime.setHours(Integer.parseInt(data[0]));      
			 appointmentDateTime.setMinutes(Integer.parseInt(data[1])); 
			 appointmentDateTime.setSeconds(0);
			 java.text.SimpleDateFormat dateFormatter = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");            
			 String appTime = dateFormatter.format(appointmentDateTime);
			AppointmentDto appointmentDto=new AppointmentDto();
			appointmentDto.setAppTime(appTime);
			appointmentDto.setDoctorId(doctor);
			appointmentDto.setPurpose(purpose);
			appointmentDto.setMrNo(mrNo);
			appointmentDto.setDayOfWeek(appointmentDay);
			objStatus=makeAppointmentService.saveMakeAppointment(appointmentDto);
		}
		
		catch(Exception e){
			
			logger.error("Exception in saveMakeAppointMent() in MakeAppointmentController "+e.getMessage(),e);
		}
		logger.info("returns from saveMakeAppointMent() in MakeAppointmentController to"+objStatus.toString());
		return objStatus.toString();
	}

	@RequestMapping(value = "/getAllDoctorScheduleTime" , method = RequestMethod.POST)  
	public @ResponseBody String getAllDoctorScheduleTime(Model model, HttpServletRequest request,
			@RequestParam(value = "doctorId") String doctorId,@RequestParam(value = "dayOfWeek") String dayOfWeek,@RequestParam(value = "appointmentDate") String appointmentDate){  
		
//		String appointmentDate=request.getParameter("appointmentDate");
		String returnStatus="";  
		   try {
			   
			   HttpSession session = request.getSession();
				String time=request.getParameter("time");
			   returnStatus=makeAppointmentService.getAllDoctorScheduleTime(doctorId,dayOfWeek,appointmentDate,time);
			   } catch (Exception e) {
				   logger.error("Exception in MakeAppointmentController getAllDoctorScheduleTime() method :"     + e); 
				   }     
		   return returnStatus; 
		   }


}





