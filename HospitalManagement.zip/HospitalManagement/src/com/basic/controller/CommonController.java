package com.basic.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.basic.dto.UserDto;
import com.basic.model.User;
import com.basic.service.CommonService;
import com.basic.service.CommonServiceImpl;
import com.basic.dto.EmployeeDTO;
@Controller
@RequestMapping("/common")
public class CommonController {
	 @Autowired
	 CommonService commonService;
	 @RequestMapping(value = "/login", method = { RequestMethod.POST,RequestMethod.GET })
	 public String login(Model model,
	   @RequestParam(value = "userId") String userId,
	   @RequestParam(value = "password") String password,
	   HttpServletRequest request, HttpServletResponse response) {
	  String retPage = "login";
	  HttpSession session = request.getSession();
	  UserDto userDTO = new UserDto();
	  try {
	   userDTO.setUserId(userId);userDTO.setPassword(password);
	   User user= commonService.login(userDTO);
	   if (user!=null) {
	   UserListener listener = new UserListener(userId);
	   session.setAttribute("UserContext", listener);
	   session.setAttribute("userId", userId);
	   session.setAttribute("groupId", user.getGroup());
	   model.addAttribute("group", user.getGroup());
	   model.addAttribute("userId", userId);
	   if(user.getGroup().equals("ADMIN")){
	   retPage="AdminDashboard";
	   }else if(user.getGroup().equals("DOCTOR")){
		   retPage="DoctorDashbard";
	   }
	   else if(user.getGroup().equals("PATIENT")){
		   retPage="PatientDashboard";
	   }
	   else{
		   return "login";
	   }
	   }else {
	    model.addAttribute("status", "Invalid UserName or Password");
	    return "login";
	   }
	 }catch(Exception e)
	  {
	  model.addAttribute("status","Server Problem please try after some time");
	  return "login";
	  }
	  return retPage;
	}



	 @RequestMapping(value = "/getallEmployess", method = { RequestMethod.POST,RequestMethod.GET })
		public @ResponseBody String login(Model model, HttpServletRequest request,
				HttpServletResponse response,@RequestParam(value = "status") String status) {
		 System.out.println(status);
			HttpSession session = request.getSession();
			String userName = (String) session.getAttribute("userId");

			String getAllDetails = "";
			try {
								System.out.println("inside method getGroupList() in GroupController "+"dddddddddddd");
				getAllDetails = commonService.getAllDetails(userName,status);
			} catch (Exception e) {
			}
			return getAllDetails;
		
		}


	 @RequestMapping(value = "/saveEmployee", method ={RequestMethod.GET,RequestMethod.POST})
     public @ResponseBody String saveDepartment(EmployeeDTO employeeDTO,HttpServletRequest request) {
	  HttpSession session=request.getSession();
	  String createdid = (String) session.getAttribute("userId");
	  employeeDTO.setEnterdby(createdid);
	  System.out.println("ssssssssssssssssssssssssssssss");
	  String returnStatus="";
         try {
          returnStatus=commonService.saveEmployee(employeeDTO);
             } catch (Exception e) {
            	 System.out.println(e.getMessage()+e);
   }
         return returnStatus;
        }

	 @RequestMapping(value = "/logOut", method = RequestMethod.GET)
	 public String logOut(HttpServletRequest request) {
	  HttpSession session = request.getSession();

	  String ipAddress = request.getHeader("X-FORWARDED-FOR");
	  if (StringUtils.isEmpty(ipAddress)) {
		  System.out.println(ipAddress + " ipAddress is empty");
	   ipAddress = request.getRemoteAddr();
	  }
	  try {
	   String userId = (String) session.getAttribute("userId");
	   System.out.println(userId + "Logged Out Successfully");
	  } catch (Exception e) {
		  System.out.println("Exception logOut() in UserController "+ e.getMessage());
	  }
	  session.removeAttribute("UserContext");
	  session.invalidate();
	  System.out.println("Return from logOut() in UserController to login");
	  return "login";
	 }

}
